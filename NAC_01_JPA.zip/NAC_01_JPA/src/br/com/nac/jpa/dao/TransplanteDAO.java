package br.com.nac.jpa.dao;

import br.com.nac.jpa.entity.Transplante;

public interface TransplanteDAO extends GenericDAO<Transplante, Integer> {

}
