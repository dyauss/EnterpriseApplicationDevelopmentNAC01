package br.com.nac.jpa.view;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import br.com.nac.jpa.dao.ReceptorDAO;
import br.com.nac.jpa.dao.impl.ReceptorDAOImpl;
import br.com.nac.jpa.entity.Cirurgiao;
import br.com.nac.jpa.entity.Doador;
import br.com.nac.jpa.entity.Estadia;
import br.com.nac.jpa.entity.Orgao;
import br.com.nac.jpa.entity.Receptor;
import br.com.nac.jpa.entity.Transplante;
import br.com.nac.jpa.exception.CommitException;
import br.com.nac.jpa.singleton.EntityManagerFactorySingleton;

public class ConsoleView {
	public static void main(String[] args) {
		
		// Instanciando a f�brica
		EntityManagerFactory fabrica = EntityManagerFactorySingleton.getInstance();
		
		// Instanciando o Entity Manager
		EntityManager em = fabrica.createEntityManager();
		
		// Instanciando o DAO
		ReceptorDAO dao = new ReceptorDAOImpl(em);
		
		// Cadastrando dados
		Cirurgiao cir = new Cirurgiao("Rodrigo", 30, Calendar.getInstance());
		
		Doador doa = new Doador("Maria", "Tipo A+");
		
		Estadia est = new Estadia(10, null);
		
		Orgao org1 = new Orgao("Cora��o", Calendar.getInstance(), Calendar.getInstance());
		
		Receptor rec = new Receptor("Marcos", "Tipo O-");
		
		Transplante tra = new Transplante(Calendar.getInstance());
		
		List<Transplante> transplantes = new ArrayList<Transplante>(); 
		transplantes.add(tra);
		cir.setTransplante(transplantes);
		rec.setTransplantes(transplantes);
		
		List<Orgao> orgaos = new ArrayList<Orgao>();
		orgaos.add(org1);
		rec.setOrgaos(orgaos);
		
		List<Cirurgiao> cirurgiaos = new ArrayList<Cirurgiao>();
		cirurgiaos.add(cir);
		tra.setCirurgiao(cirurgiaos);
		
		doa.addOrgaos(org1);
		
		est.setReceptor(rec);
		
		org1.setReceptor(rec);
		org1.setDoador(doa);
		
		tra.setReceptor(rec);
		
		
		
		try {
			dao.cadastrar(rec);	
			dao.commit();
			System.out.println("Cadastrado com sucesso!!");
		} catch (CommitException e) {
			System.out.println("Houve algum erro");
			e.printStackTrace();
		}
		
		em.close();
		fabrica.close();
		
	}
}
