package br.com.nac.jpa.dao;

import br.com.nac.jpa.entity.Receptor;

public interface ReceptorDAO extends GenericDAO<Receptor, Integer> {

}
