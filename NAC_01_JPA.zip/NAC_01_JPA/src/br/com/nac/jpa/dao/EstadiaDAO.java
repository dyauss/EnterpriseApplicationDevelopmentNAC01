package br.com.nac.jpa.dao;

import br.com.nac.jpa.entity.Estadia;

public interface EstadiaDAO extends GenericDAO<Estadia, Integer>{

}
