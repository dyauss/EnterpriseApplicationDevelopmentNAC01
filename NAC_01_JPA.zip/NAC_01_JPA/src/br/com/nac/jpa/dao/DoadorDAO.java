package br.com.nac.jpa.dao;

import br.com.nac.jpa.entity.Doador;

public interface DoadorDAO extends GenericDAO<Doador, Integer>{

}
