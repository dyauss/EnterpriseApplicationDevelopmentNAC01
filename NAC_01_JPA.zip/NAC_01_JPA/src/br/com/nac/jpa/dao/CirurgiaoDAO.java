package br.com.nac.jpa.dao;

import br.com.nac.jpa.entity.Cirurgiao;

public interface CirurgiaoDAO extends GenericDAO<Cirurgiao,Integer>{

}
